using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace UsbRemoteAssistant {
    public sealed class SetupDialog : Form {
        readonly Settings original;
        readonly bool preview;
        Settings draft;
        TextBox primary, secondary, usbPort, filePort, networkId, key, tool, inbox;
        CheckBox manage, auto;
        public SetupDialog(Settings cfg, bool isPreview) {
            original = cfg; preview = isPreview; draft = SettingsCopy.Clone(cfg);
            Text = "连接与配对 · " + Program.Role; Font = new Font("Microsoft YaHei UI", 9F);
            ClientSize = new Size(790, 700); MinimumSize = new Size(760, 700); StartPosition = FormStartPosition.CenterParent;
            var root = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(18), ColumnCount = 1, RowCount = 9 };
            int[] heights = { 36, 54, 172, 40, 43, 43, 32, 155, 42 };
            foreach (int h in heights) root.RowStyles.Add(new RowStyle(SizeType.Absolute, h)); Controls.Add(root);
            root.Controls.Add(new Label { Text = "首次配置：填写地址，生成密钥，再导出给另一端", Dock = DockStyle.Fill, Font = new Font(Font.FontFamily, 13F, FontStyle.Bold) }, 0, 0);
            root.Controls.Add(new Label { Text = "主机运行开发软件；副机连接 USB 或 Linux 板卡。\r\n两端导入同一份配对文件即可共享连接信息。配对文件包含访问密钥，只在自己的设备间传递。", Dock = DockStyle.Fill }, 0, 1);
            var grid = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 4 };
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110)); grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110)); grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            for (int i = 0; i < 4; i++) grid.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
            primary = Input(grid, "主机 IPv4", 0, 0); secondary = Input(grid, "副机 IPv4", 2, 0);
            usbPort = Input(grid, "USB 服务端口", 0, 1); filePort = Input(grid, "文件服务端口", 2, 1);
            manage = new CheckBox { Text = "由助手启动并管理 ZeroTier（已有局域网 / VPN 可不选）", AutoSize = true, Margin = new Padding(4, 8, 0, 0) };
            grid.Controls.Add(manage, 0, 2); grid.SetColumnSpan(manage, 4);
            networkId = Input(grid, "网络 ID", 0, 3); grid.SetColumnSpan(networkId, 3);
            manage.CheckedChanged += (s, e) => networkId.Enabled = manage.Checked; root.Controls.Add(grid, 0, 2);
            var pairing = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
            key = new TextBox { Width = 200, ReadOnly = true, UseSystemPasswordChar = true, Margin = new Padding(3, 7, 6, 0) }; pairing.Controls.Add(key);
            pairing.Controls.Add(Action("生成新密钥", () => { draft.PairKey = Settings.NewPairKey(); key.Text = draft.PairKey; }));
            pairing.Controls.Add(Action("导出配对文件", Export)); pairing.Controls.Add(Action("导入配对文件", Import));
            root.Controls.Add(pairing, 0, 3);
            var tools = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
            tools.Controls.Add(new Label { Text = "VirtualHere", Width = 92, Margin = new Padding(3, 9, 0, 0) });
            tool = new TextBox { Width = 365, Margin = new Padding(3, 7, 5, 0) }; tools.Controls.Add(tool);
            tools.Controls.Add(Action("选择程序", () => { using (var pick = new OpenFileDialog { Filter = "Windows 程序|*.exe", Title = Program.IsPrimary ? "选择 VirtualHere Client" : "选择 VirtualHere Server" }) { if (pick.ShowDialog(this) == DialogResult.OK) tool.Text = pick.FileName; } }));
            tools.Controls.Add(Action("官网下载", () => Process.Start(Program.IsPrimary ? "https://www.virtualhere.com/usb_client_software" : "https://www.virtualhere.com/windows_server_software")));
            root.Controls.Add(tools, 0, 4);
            var folders = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
            folders.Controls.Add(new Label { Text = "接收目录", Width = 92, Margin = new Padding(3, 9, 0, 0) });
            inbox = new TextBox { Width = 600, Margin = new Padding(3, 7, 3, 0) }; folders.Controls.Add(inbox); root.Controls.Add(folders, 0, 5);
            auto = new CheckBox { Text = "下次打开软件后自动开启服务", AutoSize = true }; root.Controls.Add(auto, 0, 6);
            root.Controls.Add(new TextBox { Dock = DockStyle.Fill, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, Text = AdapterText(), BackColor = Color.FromArgb(246, 248, 251) }, 0, 7);
            var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
            buttons.Controls.Add(Action("保存配置", Save)); buttons.Controls.Add(Action("取消", () => { DialogResult = DialogResult.Cancel; Close(); })); root.Controls.Add(buttons, 0, 8);
            LoadFields();
        }
        TextBox Input(TableLayoutPanel grid, string label, int column, int row) {
            grid.Controls.Add(new Label { Text = label, AutoSize = true, Margin = new Padding(3, 9, 0, 0) }, column, row);
            var input = new TextBox { Dock = DockStyle.Fill, Margin = new Padding(3, 6, 10, 4) }; grid.Controls.Add(input, column + 1, row); return input;
        }
        Button Action(string label, System.Action callback) {
            var button = new Button { Text = label, AutoSize = true, MinimumSize = new Size(90, 31), Margin = new Padding(3, 3, 3, 3) };
            button.Click += (s, e) => { try { callback(); } catch (Exception ex) { MessageBox.Show(this, ex.GetBaseException().Message, "配置未完成"); } }; return button;
        }
        void LoadFields() {
            primary.Text = draft.PrimaryIp; secondary.Text = draft.SecondaryIp; usbPort.Text = draft.UsbPort.ToString(); filePort.Text = draft.TransferPort.ToString();
            manage.Checked = draft.ManageZeroTier; networkId.Text = draft.NetworkId; networkId.Enabled = manage.Checked;
            key.Text = draft.PairKey ?? ""; tool.Text = draft.VirtualHerePath; inbox.Text = draft.ReceiveFolder; auto.Checked = draft.AutoStart;
        }
        Settings ReadFields() {
            int usb, files;
            if (!Int32.TryParse(usbPort.Text, out usb) || !Int32.TryParse(filePort.Text, out files)) throw new IOException("端口应为整数。");
            var candidate = SettingsCopy.Clone(draft);
            candidate.PrimaryIp = primary.Text.Trim(); candidate.SecondaryIp = secondary.Text.Trim(); candidate.UsbPort = usb; candidate.TransferPort = files;
            candidate.ManageZeroTier = manage.Checked; candidate.NetworkId = manage.Checked ? networkId.Text.Trim() : "";
            candidate.PairKey = key.Text; candidate.VirtualHerePath = tool.Text.Trim().Trim('"'); candidate.ReceiveFolder = inbox.Text.Trim(); candidate.AutoStart = auto.Checked;
            if (!candidate.ManageZeroTier) candidate.StopZeroTier = false;
            candidate.Validate(); return candidate;
        }
        void Export() {
            var candidate = ReadFields();
            using (var pick = new SaveFileDialog { FileName = "usb-remote.pairing.json", Filter = "配对文件|*.pairing.json" }) {
                if (pick.ShowDialog(this) == DialogResult.OK) File.WriteAllText(pick.FileName, JsonData.Write(PairingDocument.From(candidate)), new UTF8Encoding(false));
            }
        }
        void Import() {
            using (var pick = new OpenFileDialog { Filter = "配对文件|*.pairing.json|JSON 文件|*.json" }) {
                if (pick.ShowDialog(this) != DialogResult.OK) return;
                var candidate = SettingsCopy.Clone(draft); PairingDocument.Load(pick.FileName).ApplyTo(candidate); draft = candidate; LoadFields();
            }
        }
        void Save() {
            var candidate = ReadFields();
            if (!preview) candidate.Save(); SettingsCopy.Apply(candidate, original); DialogResult = DialogResult.OK; Close();
        }
        string AdapterText() {
            if (preview) return "本机 IPv4 地址会在实际运行时列出。公开软件包不包含任何用户配置。\r\nVirtualHere 需从官网单独获取；不用 USB 时，文件传输和板卡 SSH 可以独立使用。\r\n首次配置建议：生成新密钥 → 导出配对文件 → 保存配置 → 在另一端导入。";
            var rows = NetworkInterface.GetAllNetworkInterfaces().Where(n => n.OperationalStatus == OperationalStatus.Up)
                .SelectMany(n => n.GetIPProperties().UnicastAddresses.Where(a => a.Address.AddressFamily == AddressFamily.InterNetwork).Select(a => n.Name + " : " + a.Address));
            return "本机可用 IPv4（当前程序为" + Program.Role + "）：\r\n" + String.Join("\r\n", rows) + "\r\n\r\nVirtualHere 需自行获取；只用文件传输或 SSH 可不选择。接收目录留空时使用用户下载目录。\r\n更改 USB 端口时，需在 VirtualHere Server 中配置相同端口。";
        }
        public void RenderPreview(string path) {
            Show(); Application.DoEvents();
            using (var bitmap = new Bitmap(Width, Height)) { DrawToBitmap(bitmap, new Rectangle(0, 0, Width, Height)); bitmap.Save(path, System.Drawing.Imaging.ImageFormat.Png); }
            Hide();
        }
        protected override bool ShowWithoutActivation { get { return preview; } }
    }
}
