using System;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;

namespace UsbRemoteAssistant {
    [DataContract]
    public sealed class PairingDocument {
        [DataMember] public string Kind = "usb-remote-assistant-pairing";
        [DataMember] public int FormatVersion = 1;
        [DataMember] public bool ManageZeroTier;
        [DataMember] public string NetworkId, PrimaryIp, SecondaryIp, PairKey;
        [DataMember] public int UsbPort, TransferPort;
        public static PairingDocument From(Settings cfg) {
            cfg.Validate();
            return new PairingDocument { ManageZeroTier = cfg.ManageZeroTier, NetworkId = cfg.ManageZeroTier ? cfg.NetworkId : "", PrimaryIp = cfg.PrimaryIp, SecondaryIp = cfg.SecondaryIp, PairKey = cfg.PairKey, UsbPort = cfg.UsbPort, TransferPort = cfg.TransferPort };
        }
        public void ApplyTo(Settings cfg) {
            if (Kind != "usb-remote-assistant-pairing" || FormatVersion != 1) throw new IOException("这不是支持的配对文件。");
            var candidate = new Settings { ManageZeroTier = ManageZeroTier, NetworkId = NetworkId ?? "", PrimaryIp = PrimaryIp, SecondaryIp = SecondaryIp, PairKey = PairKey, UsbPort = UsbPort, TransferPort = TransferPort };
            candidate.Validate();
            cfg.ManageZeroTier = candidate.ManageZeroTier; cfg.NetworkId = candidate.NetworkId;
            cfg.PrimaryIp = candidate.PrimaryIp; cfg.SecondaryIp = candidate.SecondaryIp; cfg.PairKey = candidate.PairKey;
            cfg.UsbPort = candidate.UsbPort; cfg.TransferPort = candidate.TransferPort;
            cfg.DeviceVendor = 0; cfg.DeviceProduct = 0; cfg.DeviceSerial = ""; cfg.BoardEnabled = false;
        }
        public static PairingDocument Load(string path) {
            if (new FileInfo(path).Length > 65536) throw new IOException("配对文件过大。");
            return JsonData.Read<PairingDocument>(File.ReadAllText(path));
        }
    }
    public static class SettingsCopy {
        public static Settings Clone(Settings settings) { return JsonData.Read<Settings>(JsonData.Write(settings)); }
        public static void Apply(Settings source, Settings target) {
            // Public configuration fields only; no live service objects are part of Settings.
            foreach (var field in typeof(Settings).GetFields(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance)) field.SetValue(target, field.GetValue(source));
        }
    }
}
