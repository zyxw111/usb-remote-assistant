# Configuration examples

The program starts without configured addresses, network ID, device identity or pairing key. Use the setup dialog to generate a real pairing document.

For documentation only, a pair might use `192.0.2.10` and `192.0.2.20`; a Linux board might use `198.51.100.2`. These are documentation addresses, not working defaults. Replace them with addresses actually assigned to your own interfaces.

Do not put an exported pairing document here. The export contains a secret and belongs outside a public repository.
